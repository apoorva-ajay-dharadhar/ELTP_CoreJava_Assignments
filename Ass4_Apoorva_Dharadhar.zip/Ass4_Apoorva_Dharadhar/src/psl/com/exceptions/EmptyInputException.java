package psl.com.exceptions;

public class EmptyInputException extends Exception{
public EmptyInputException(String name)
{
	super(name);
}
}
